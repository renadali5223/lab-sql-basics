SELECT amount
FROM loan
ORDER BY amount
LIMIT 3;
SELECT loan_id
FROM loan
ORDER BY payments DESC
LIMIT 1;

SELECT account_id, SUM(amount) AS total_loans
FROM loan
GROUP BY account_id
ORDER BY total_loans DESC
LIMIT 10;

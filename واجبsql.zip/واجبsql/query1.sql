-- Query 1
SELECT client_id 
FROM client 
WHERE district_id = 1 
ORDER BY client_id 
LIMIT 5;


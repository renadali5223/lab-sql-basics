SELECT type, COUNT(*) AS total_cards
FROM card
GROUP BY type
ORDER BY total_cards DESC;
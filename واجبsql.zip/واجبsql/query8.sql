SELECT DISTINCT k_symbol
FROM `order`;

-- Query 9
SELECT order_id
FROM `order`
WHERE account_id = 34;

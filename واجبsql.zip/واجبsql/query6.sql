SELECT account_id, amount
FROM loan
ORDER BY account_id
LIMIT 5;
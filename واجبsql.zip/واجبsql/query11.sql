
SELECT amount
FROM `order`
WHERE account_to = 30067122;